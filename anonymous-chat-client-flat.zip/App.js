import React, { useEffect, useState } from 'react';
import { auth, provider } from './firebase';
import { signInWithPopup } from 'firebase/auth';
import io from 'socket.io-client';

const socket = io('https://your-backend-url.railway.app');

function App() {
  const [user, setUser] = useState(null);
  const [rooms, setRooms] = useState([]);

  const signIn = async () => {
    const result = await signInWithPopup(auth, provider);
    const email = result.user.email;
    if (!email.endsWith('@cmu.edu.tw')) {
      alert('只允許 cmu.edu.tw 登入');
      return;
    }
    setUser(result.user);
    socket.emit('register', { gender: 'male' }); // 根據你的 UI 設定
  };

  useEffect(() => {
    socket.on('matched', ({ roomId, users }) => {
      setRooms(prev => [...prev, { id: roomId, users }]);
    });
  }, []);

  const sendMessage = (roomId, msg) => {
    socket.emit('message', { roomId, message: msg });
  };

  return (
    <div>
      {!user && <button onClick={signIn}>使用 Google 登入</button>}
      {rooms.map(room => (
        <div key={room.id}>
          <h3>房間 {room.id}</h3>
          <input
            type="text"
            onKeyDown={e => e.key === 'Enter' && sendMessage(room.id, e.target.value)}
            placeholder="輸入訊息"
          />
        </div>
      ))}
    </div>
  );
}

export default App;
