const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const waitingQueue = {
  male: [],
  female: []
};

const activeChats = {}; // userId -> [roomId1, roomId2, roomId3]

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('register', ({ gender }) => {
    socket.gender = gender;
    socket.chats = [];
    attemptMatch(socket);
  });

  socket.on('message', ({ roomId, message }) => {
    io.to(roomId).emit('message', { from: socket.id, message });
  });

  socket.on('leave', ({ roomId }) => {
    socket.leave(roomId);
    socket.chats = socket.chats.filter(id => id !== roomId);
    io.to(roomId).emit('user-left', { userId: socket.id });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
    socket.chats.forEach(roomId => {
      io.to(roomId).emit('user-left', { userId: socket.id });
    });
  });
});

function attemptMatch(socket) {
  const queue = waitingQueue[socket.gender === 'male' ? 'female' : 'male'];
  while (queue.length > 0 && socket.chats.length < 3) {
    const partner = queue.shift();
    if (partner.chats.length >= 3) continue;

    const roomId = `room-${socket.id}-${partner.id}`;
    socket.join(roomId);
    partner.join(roomId);

    socket.chats.push(roomId);
    partner.chats.push(roomId);

    io.to(roomId).emit('matched', { roomId, users: [socket.id, partner.id] });
  }

  if (socket.chats.length < 3) {
    waitingQueue[socket.gender].push(socket);
  }
}

server.listen(3000, () => console.log('Server running on http://localhost:3000'));
